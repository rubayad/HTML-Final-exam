const header = document.createElement('header');
const footer = document.createElement('footer');


header.innerHTML = `
    <div class="left-item">
        <img src="./img/sample-logo.png" class="header-logo" alt="header logo">
    </div>
    <div class="middle-item">
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </div>
    <div class="right-item">
        <form>
            <input type="search" name="search" placeholder="Search">
        </form>
    </div>
`;

document.body.insertBefore(header, document.body.firstChild);


footer.innerHTML = `
<div class="footer-logo">
<img src="./img/sample-logo.png" alt="sample logo">
</div>

<div class="footer-text">
<h3>Title</h3>
<p>    Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias dolorum vitae ratione totam non repudiandae autem provident veniam rem delectus?</p>
</div>  
`;

document.body.appendChild(footer);